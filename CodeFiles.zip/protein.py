#!/usr/local/bin/python3

#script to determine and plot protein seq.
#Written by B189286
#------------------------------------------------------------------#

import os, sys, subprocess
print ("\nModules imported: os, sys, subprocess\n")

os.system('clear')
#___________________________________________________________________________#

#FUNCTION to get input from user
#Arguments will come in as a list from the dictionary of details provided

def user_entry(protein, taxonomic_group):
        import string
        print("You have provided the following details:\n\tProtein family: ",protein,"\n\tTaxonomic group: ",taxonomic_group)


#Store the output in an ordered dictionary

details={}
details["protein"] = input("Please enter the protein family: ")
details["taxonomic_group"] = input("Please enter the taxonomic group: ")

user_entry(*list(details.values()))

mycommand="esearch -db protein -query '{0}[organism] AND {1}[Protein name] NOT PARTIAL' | efetch -format fasta > {0}_esearch.fasta ".format(details["taxonomic_group"], details["protein"])
subprocess.call(mycommand, shell = True)

